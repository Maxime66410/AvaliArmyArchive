Steps To Add the Da'Vali Warmers.

1. Drag the FBX for your desired version into your project file.
	
	-- After Importing Click on the prefab and in your inspector select Rig > and change type to Humanoid, then select Copy from Other Avatar, and for the Source use your Avali's Mesh (usually Avali updatedAvatar) and hit apply.

2. Import Textures or create your own

3. Drag the prefab into your hierarchy and right click on the prefab in your hierarchy and select unpack prefab.

4. Drag the Arm/Leg Warmers under your Model Making sure it shows as follows

    --Davali Base
        Armature
        Body
        ChestFluff
        Arm/Leg Warmers

	NOTE: To make sure the Animations later on work correctly, rename the file you just moved to either "Arm Warmers" or "Leg Warmers" respectively, otherwise it may not work (more like probably wont work).


5. Drag the Warmers Armature under the Armature and unpack the armature under each respective part aka. Warmers Hips to Hips etc etc.

6. Create a new material by right clicking in your assets and going to new > Material. drag the material ball onto the warmers in your scene.

7. Apply your prefered Shaders and Textures.

8. Add your animations by any means you deem nesscary, premade basic animations for showing and hiding the warmers are included.

9. ????

10. Enjoy your Fancy New Warmers for your amonia based Birb... (wait why did they need this in the first place... guess they are cute :3)

Any Issues with the steps laid out in this readme please dont be afraid to tell me, im learning just like you probably are, the more we help eachother the further we can go!

- NocturnalSergal#8746


PS. Yeah i know its alot of steps, most of which i could cut out by making a unitypackage but, i have no flipping idea how to make one and its midnight after having a ureka moment in fixing this.