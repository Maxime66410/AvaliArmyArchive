#########################################################
## Thank you for getting the Avali HexaVisor 3D Model! ##
#########################################################



How to use the Textures
=======================

All the Textures are in monochrome grey, which means that you can easily adjust them to your preferred color.
Simply import them to Unity, Neos, or whichever program you want to use them,
select a Standard Specular shader for all Materials - setting the Materials for the Visor and Display to Transparent, but for the Emitter to Opaque,
then adjust the HDR or Tint values on the Albedo and Emission textures.



Where to get the Da'vali Model
==============================

The Da'vali model can be gotten for free.
Simply join this Discord Server, accept the rules in #davali-avatar-rules and grab the files from #davali-assets.

https://discord.gg/avali

If you need any help with these files, feel free to ask there, contact me on Twitter, or find me on any of the other servers I'm on.



License
=======

These meshes, textures and the substance file are free / PWYW, so you're free to distribute the contents.
You can't claim that you've created them though, and I'd appreciate linking back to the Gumroad page as a source if you get asked.
The original model for the visor was made by Brins0, which was extended and received new textures from me.


Have fun,
 ~Banane9

https://gumroad.com/Dolphinitely
https://twitter.com/DolphinitelyG