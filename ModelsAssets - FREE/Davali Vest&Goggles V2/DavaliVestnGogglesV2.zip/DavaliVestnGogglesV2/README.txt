How to apply the Vest&Goggles to your Davali avatar

This guide assumes you have some basic knowledge of Unity and this isn't your first time making a VRChat avatar.
You may or may not have used the Poiyomi shader on your avatars before.

The Da'Vali model can be found at the official Avali Army server: discord.gg/avali

---------------------

What this package contains:
- The .blend files for the vest and goggles for editing.
- .psd texture files for Photoshop as well as .xcf files for GIMP
- .unitypackage containing the model and ready-to-use materials for both PC and Quest

The goggles contain a blendshape that allows you to place them on the forehead.

Both the vest and goggles come in 3 color varians:
- Plain leather (Default)
- Black leather and gold (Cool Drip)
- White and orange (Avalon Exploration Force)

---------------------

Adding the clothes to your avatar requires the Apply Accessories script by Artieficial

Download the latest version of Apply Accessories script from here
https://github.com/artieficial/ApplyAccessories/releases

YouTube tutorial on how to use the Apply Accessories script:
https://www.youtube.com/watch?v=d1GgVg75NGA

--------------------

The vest materials require Poiyomi Toon Shader
Download the shader from here:
https://github.com/poiyomi/PoiyomiToonShader/releases

Make sure to import it before you import the vest Unity package.

--------------------

After you have applied the clothes to the avatar using the ApplyAccessories script, you can create toggles for it: toggle them on and off, changing goggles position or even changing the color scheme.
If you don't know how to do that already, there is a YouTube tutorial for beginners:
https://www.youtube.com/watch?v=XqtSg6_W07Y
Since the Davali avatar already has a menu and expression parameters, you don't have to create new ones and simply edit those that already exist.
