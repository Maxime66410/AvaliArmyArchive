Instructions: 

	-Import Unity package into the project with your avatar.
	-Find the prefab which corresponds to your avatar and drag it onto your avatar in the hierarchy.
	-Right-click on the prefab and click Unpack Prefab.
	-Find the Top bone inside the prefab and drag it to either UpperEarsEnd_L (for the Davali) or L.EarTop3 (for the Kitavali).
	-FOR DAVALI ONLY: Find and click on Root_Ears bone. Find the VRC Phys Bone Script which has UpperEars_L as a Root Transform. Increase the Size of Ignore Transforms by 1 and drag Top into the element it creates.
	-FOR KITAVALI ONLY: Find and click on EarsRoot bone. Find the VRC Phys Bone Script which has L.EarTop2 as a Root Transform. Increase the Size of Ignore Transforms by 1 and drag Top into the element it creates.



Avali cancer awareness ribbon by Isazap.
 
isazap.gumroad.com

Discord: isazap
