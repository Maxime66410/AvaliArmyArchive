<!-- docs/_sidebar.md -->

* [Home](/)
* [Quick Start](QUICKSTART.md)
* [Customization](CUSTOMIZATION.md)
  * [Flight Physics](FlightPhysics.md)
  * [Themes](Themes.md)
* [Adding Avatars](ADDINGAVATARS.md)
* [Scripting Reference](Doxygen/html/index.html ":ignore title")
