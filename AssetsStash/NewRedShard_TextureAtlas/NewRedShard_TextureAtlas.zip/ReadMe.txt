Hello, Nicoreda here.
Feel free to use theses textures for your VRCHAT level.
They are PBR, which mean they have bump, metal and reflection data.
It is an atlas, so you have to play with your UV map to make them show properly.
You are not allowed to make a new download link, but feel free to send the link.
