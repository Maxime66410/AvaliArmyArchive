Hello, this file has been uploaded by Nicoreda to the Avali Army discord.
Original model is made by VictonRoy, Only some tweaks has been done. Please do not share this file beside sending the link to the avali army.
