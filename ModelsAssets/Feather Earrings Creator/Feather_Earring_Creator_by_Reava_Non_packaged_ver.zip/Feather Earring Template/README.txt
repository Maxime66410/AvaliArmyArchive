Hi! This is a simple "prefab" to help you share your feather to your friends and loved ones, just open the PSD and follow instructions ^^

Terms of service:
- Don't charge money in exhange for using this tool.
- Don't sell this.
- Just be a good bird okay? thanks

Instructions:
- Open the PSD
- Replace the corresponding texture with yours in the PSD
- Export as PNG/JPEG back to Unity
- Replace Material in the Templates folder with your new texture 
(or Make a copy of your avatar's feathers material and replace the textures with what you just made)

 Need support or questions? -> https://discord.gg/TxYwUFKbUS
 Find all my socials here -> https://linktr.ee/Reava_

 Enjoy sharing and wearing your friends feathers! <3

 Share the love, from Reava